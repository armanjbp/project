package com.virtusa.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.virtusa.model.Result;
import com.virtusa.service.ResultService;

@Controller
@RequestMapping(value = "/ticket")
public class ResultController {

	@Autowired
	private ResultService ResultService;

	@RequestMapping(value = "/add", method = RequestMethod.GET)
	public ModelAndView addTeamPage() {
		ModelAndView modelAndView = new ModelAndView("add-result-form");
		modelAndView.addObject("ticket", new Result());
		return modelAndView;
	}

	@RequestMapping(value = "/add", method = RequestMethod.POST)
	public ModelAndView addingTicket(@ModelAttribute Result ticket) {

		ModelAndView modelAndView = new ModelAndView("welcome");
		ResultService.addResult(ticket);

		String message = "Result was successfully added.";
		modelAndView.addObject("message", message);

		return modelAndView;
	}

	@RequestMapping(value = "/list")
	public ModelAndView listOfTickets() {
		ModelAndView modelAndView = new ModelAndView("list-of-result");

		List<Result> tickets = ResultService.getResult();
		modelAndView.addObject("teams", tickets);

		return modelAndView;
	}

	@RequestMapping(value = "/edit/{id}", method = RequestMethod.GET)
	public ModelAndView editTicketPage(@PathVariable Integer id) {
		ModelAndView modelAndView = new ModelAndView("edit-result-form");
		Result ticket = ResultService.getResult(id);
		modelAndView.addObject("ticket", ticket);
		return modelAndView;
	}

	@RequestMapping(value = "/edit/{id}", method = RequestMethod.POST)
	public ModelAndView edditingTicket(@ModelAttribute Result ticket, @PathVariable Integer id) {

		ModelAndView modelAndView = new ModelAndView("welcome");

		ResultService.updateResult(ticket);

		String message = "Result was successfully edited.";
		modelAndView.addObject("message", message);

		return modelAndView;
	}

	@RequestMapping(value = "/delete/{id}", method = RequestMethod.GET)
	public ModelAndView deleteTicket(@PathVariable Integer id) {
		ModelAndView modelAndView = new ModelAndView("welcome");
		ResultService.deleteResult(id);
		String message = "Result was successfully deleted.";
		modelAndView.addObject("message", message);
		return modelAndView;
	}

}
