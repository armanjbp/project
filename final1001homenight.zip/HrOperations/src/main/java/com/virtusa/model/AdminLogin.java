package com.virtusa.model;

public class AdminLogin {
	private String Adminusername;
	private String Adminpassword;

	public String getAdminusername() {
		return Adminusername;
	}

	public void setAdminusername(String adminusername) {
		Adminusername = adminusername;
	}

	public String getAdminpassword() {
		return Adminpassword;
	}

	public void setAdminpassword(String adminpassword) {
		Adminpassword = adminpassword;
	}

}
