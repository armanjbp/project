package com.virtusa.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.virtusa.dao.ResultDAO;
import com.virtusa.model.Result;

@Service
@Transactional
public class ResultServiceImpl implements ResultService {

	@Autowired
	private ResultDAO resultDAO;

	public void addResult(Result ticket) {
		resultDAO.addResult(ticket);

	}

	public void updateResult(Result ticket) {
		resultDAO.updateResult(ticket);

	}

	public Result getResult(int id) {
		return resultDAO.getResult(id);
	}

	public void deleteResult(int id) {
		resultDAO.deleteResult(id);

	}

	public List<Result> getResult() {
		return resultDAO.getResult();
	}

}
