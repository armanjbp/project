package com.virtusa.service;

import com.virtusa.model.Login;
import com.virtusa.model.User;

public interface UserService {

  int register(User user);

  User validateUser(Login login);
}
