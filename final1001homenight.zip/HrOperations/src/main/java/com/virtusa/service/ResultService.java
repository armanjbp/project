package com.virtusa.service;

import java.util.List;

import com.virtusa.model.Result;

public interface ResultService {

	public void addResult(Result ticket);
	public void updateResult(Result ticket);
	public Result getResult(int id);
	public void deleteResult(int id);
	public List<Result> getResult();

}
