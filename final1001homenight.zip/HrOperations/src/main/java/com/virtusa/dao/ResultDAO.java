package com.virtusa.dao;

import java.util.List;

import com.virtusa.model.Result;

public interface ResultDAO {

	public void addResult(Result result);
	public void updateResult(Result result);
	public Result getResult(int id);
	public void deleteResult(int id);
	public List<Result> getResult();

}
