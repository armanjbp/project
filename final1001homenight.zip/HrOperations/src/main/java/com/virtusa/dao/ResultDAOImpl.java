package com.virtusa.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.virtusa.model.Result;

@Repository
public class ResultDAOImpl implements ResultDAO {
	
	@Autowired
	private SessionFactory sessionFactory;
	
	private Session getCurrentSession() {
		return sessionFactory.getCurrentSession();
	}

	public void addResult(Result result) {
		getCurrentSession().save(result);
		
	}

	public void updateResult(Result result) {
		Result ResultToUpdate = getResult(result.getId());
		ResultToUpdate.setName(result.getName());
		ResultToUpdate.setResult(result.getResult());
		getCurrentSession().update(ResultToUpdate);
		
	}

	public Result getResult(int id) {
		Result Result = (Result) getCurrentSession().get(Result.class, id);
		return Result;
	}

	public void deleteResult(int id) {
		Result Result = getResult(id);
		if (Result != null)
			getCurrentSession().delete(Result);		
	}

	@SuppressWarnings("unchecked")
	public List<Result> getResult() {
		return getCurrentSession().createQuery("from Result").list();
	}

}
